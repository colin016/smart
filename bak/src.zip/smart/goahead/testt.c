﻿
int test_getlogfile(int type, char *name)
{
	return 0;
}

int test_update(void)
{
	return 0;
}
