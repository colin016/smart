﻿//系统主函数及web后台处理，由goahead.c改进而来
//#include "goahead.h"
#include "smart.h"

//static void ui_showsysinfo(Webs *wp);
/*......

static void actionTest(Webs *wp)
{
	//analyse parameter
	
	if(manage_control(SYSTEM_FUNC, SYS_INFO, NULL, (struct system_inf *)buf)
	{
		
		//other process
	}
}
*/

int main( )
{
	if(man_init() == FALSE)
		return -1;
	
	//......
	
	man_close();
	
}
