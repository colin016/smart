﻿#include <stdio.h>
#include "proto.h"
#include "sys.h"

int main_callback(int sendid, int recvid, int type, void *input, void *output);

int main()
{
	int ret = 0,i;
	struct ModuleInfo modinf;
	char Buffer[40];

	memset(&modinf,0,sizeof(struct ModuleInfo));

	ret = proto_init(NULL, main_callback, &modinf);
	
	if(ret <= -1)
	{
		printf("初始化失败，程序退出\n");
		return -1;
	}
	
	while(1)
	{
		//提示信息
		puts("\n选择要测试的功能:");
		puts("1: 获取模块的当前配置");		
		puts("2: 获取所有关联人数量\n");
		puts("quit: 退出程序\n");

		//等待用户输入
		fgets(Buffer,sizeof(Buffer),stdin);
		if(!strlen(Buffer)) //如果没有输入信息，继续循环
			continue;
			
		if(Buffer[0] == '1')
			i = 1;
		else if(Buffer[0] == '2')
			i = 2;
		else
		{
			//程序的一个退出条件
			if(!strncmp(Buffer, "quit", 4)) 
			{
				break;
			}
			else
			{
				printf("输入错误：%s", Buffer);
				continue;
			}			
		}
		
		//执行用户选择
		switch(i)
		{
		case 1:
		{
			KeyValueArray  cfg;
			modinf.control(0, 3, NULL, &cfg);
		}
			break;
		case 2:
		{
			int type=2, num;
			modinf.control(0, 11, &type, &num);
		}
			break;
		default:
			printf("ERROR!\n");
		}
		
	}	
	
	//程序退出处理
	modinf.close( );

    return 0;
}


int main_callback(int sendid, int recvid, int type, void *input, void *output)
{
    int ret = 0;

    printf("callback is called!\n");
	printf("sendid=%d recvid=%d type=%d\n",sendid, recvid, type);
	
    return ret;
}
