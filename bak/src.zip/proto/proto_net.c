﻿#include "proto.h"

//引用模块变量
extern struct proto_data *protodata;

extern void show(char *, int );

//将msg加入重发队列
int add_sendpkt(struct pkt_inf *msg)
{
	/*struct sendpkt_node wait_node;
	protodata->plat_inf.waitlist = (struct sendpkt_node *)malloc(sizeof(struct sendpkt_ndoe));	
	if(NULL == protodata->plat_inf.waitlist)
	{
		printf("waitlist malloc error!!!\n");
		return FAIL;
	}

	wait_node.pkt_inf = (*msg);
	wait_node.sendcnt ++;

	if(NULL == protodata->plat_inf.waitlist->front)
	{
		protodata->plat_inf.waitlist->front = wait_node;
		protodata->plat_inf.waitlist->next = NULL;
	}
	else
	{
		protodata->plat_inf.waitlist->next = wait_node;
		proto
	}*/
    return 0;
}

//重新发送等待队列的对应报文
int resend_wait(struct pkt_inf *msg, struct relater_inf *rel)
{
	return 0;
}

//清除重发等待队列报文
int resend_clear(void *node,int sort)
{
	return 0;
}

//进行接收报文后的检查或者重发处理
int recv_check(struct pkt_inf *msg)
{
	int ret = 0;
	struct plat_inf  *plat;
	struct relater_inf *rel;
	
	if(msg->basehead->sort == SORT_USERAPP)
	{
		rel = msg->own_node;
		rel->recvtime = msg->recvtime;
		//if(!(msg->opt& OPT_TRANSFER)) //如果是直接访问前端设备的，重置地址
		//{
		//	memcpy(&rel->addr, &msg->peeraddr, sizeof(struct sockaddr_in);
		//}
		if(msg->basehead->opt& OPT_TRANSFER)
		{
			protodata->platinf.recvtime = msg->recvtime;
		}
			//如果不是保活请求报文
		if(!(msg->basehead->cmd == ZNAFCMD_LOGIN && msg->basehead->type == TYPE_LOGIN_KEEPQUEST))
		{
			if(msg->basehead->sendseq < rel->recvseq)//如果收到一个比上次报文序号还小的报文
				ret = -1;
			else if(msg->basehead->sendseq == rel->recvseq)//如果收到一个与上次报文序号一样的报文
			{
				ret=resend_wait(msg, rel); //在等待队列中找对应的应答报文直接发送。
				if(ret == 0)//如果发送成功
					ret = 1;//返回后不需要再处理发送
				else
					ret = 0; //返回后重新处理发送
			}
			else //如果大于当前序号，删除等待队列
			{
				rel->recvseq = msg->basehead->sendseq;
				resend_clear(rel,msg->basehead->sort); //清除等待队列报文
			}
		}
	}
	else //与服务器通信
	{
		plat = msg->own_node;
		plat->recvtime = msg->recvtime;
		if(!(msg->basehead->cmd == ZNAFCMD_LOGIN && msg->basehead->type == TYPE_LOGIN_KEEPREPLY)) //如果不是保活应答报文
		{
			if(msg->basehead->ackseq >= plat->recvseq)//如果收到确认序号大于等于上次请求序号的报文
				resend_clear(plat, msg->basehead->sort ); //清除等待队列报文;
		}
	}
		
    return ret;
}

int proto_recvproc(struct pkt_inf *msg) 
{
	int ret = 0;
	
	ret = parse_pkthead(msg);//首部解析
	if(-1 == ret)
	{
		exit(1);
	}

	if(ret == 0 && msg->own_node)//没有错误且已经找到信息节点
        ret= recv_check(msg); //重发检查
	
	if(ret == 0)
		ret = proto_deal(msg); //新报文解析处理
	
	return ret;
}

//对于要新发送的报文，形成报文之后，进行发送后处理
//type=2表示直接发送给平台服务器，0表示发送给管理APP，1表示通过平台发送给管理APP
int proto_sendproc(struct pkt_inf *msg, int type)
{
	int len, ret = 0;
	int sendtime = 0;

	plat_inf *platinf = NULL;
	relater_inf *relaterinf = NULL;
	
	PLOG("proto_sendproc start!!\n");
	if (type == REMOTE_TYPE_PLAT)
		platinf = (plat_inf *)msg->own_node;
	else
		relaterinf = (relater_inf *)msg->own_node;

    //获取发送序号
    if (type == REMOTE_TYPE_PLAT)
        msg->basehead->sendseq = ++ protodata->platinf.sendseq;
    else
        msg->basehead->sendseq  = ++ protodata->userlist->node.sendseq;

	//报文首部封装
    len = encap_pkthead(msg, type);
	msg->peeraddr.sin_addr.s_addr = inet_addr("192.168.1.102");
	msg->peeraddr.sin_port = htons(5678);
	PLOG("send,sizeof(msg->buff)=%d\n", sizeof(msg->buff));
	show(msg->buff, 1400);
	len = 480;//要看服务器最大接受缓存时多少
	//数据发送
	ret = sendto(protodata->sockfd, msg->buff, 480, 0,(struct sockaddr *)&msg->peeraddr,sizeof(struct sockaddr_in));
	if (ret <= 0)
	{
		proto_errlog( "重发应答报文失败\n",ERRLOG_MODE);//写日志
		ret = -1;
	}
	else	
	{
		PLOG("send success!!!\n");
		protodata->sendnum++;//更新发送报文数量
		
        //更新节点最新报文发送时间
		sendtime = time(NULL);
        if (type == REMOTE_TYPE_PLAT)
			protodata->platinf.sendtime = sendtime;
        else
			protodata->userlist->node.sendtime = sendtime;
	}
	
	//添加数据到发送列表，等待确认或者重发
	if(!(msg->basehead->cmd == ZNAFCMD_LOGIN && msg->basehead->type == TYPE_LOGIN_KEEPQUEST))//如果不是保活请求
	{
		ret = add_sendpkt(msg);
		if (ret == 0)
		{
			if (type == REMOTE_TYPE_PLAT)
				protodata->platinf.waitnum ++;
			else
				protodata->userlist->node.waitnum ++;
		}
	}

	return ret;
}


int proto_netinit(void)
{
	int sockfd = 0;
	
	struct sockaddr_in local_addr;
	int sockaddr_len = sizeof(struct sockaddr_in);

		//建立套接字
	//sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd < 0)
	{
		proto_errlog("166套接字初始化失败", ERRLOG_MODE);
		return -1;
	}
	PLOG("sockfd = %d\n", sockfd);
	
	memset(&local_addr,0,sockaddr_len);
	local_addr.sin_family = AF_INET;
	local_addr.sin_port = htons(protodata->cfg.locport);
	local_addr.sin_addr.s_addr = INADDR_ANY;

	//绑定端口
	if( bind(sockfd, (struct sockaddr*)&local_addr, sockaddr_len) != 0 )
	{
		proto_errlog( "套接字绑定端口失败",ERRLOG_MODE);//写日志
		close(sockfd);
		return -2;
	}
	
	return sockfd;
}


void *proto_nethandle(void *arg) //接收处理线程
{
	int socket_fd = *(int *)arg;
	char buff[1500];
	int datalen;
	int sockaddr_len;
	struct pkt_inf msg;
	
	//循环运行recvfrom接收信息
	while (protodata->nethandle_run)
	{
		memset(buff,0,DATA_MAXLEN);
		memset(&msg,0,sizeof(struct pkt_inf));		

		datalen = recvfrom(socket_fd, buff, DATA_MAXLEN, 0,(struct sockaddr *)&msg.peeraddr,&sockaddr_len);
		if (datalen < DATA_HEADLEN) //如果不足基本首部长度
		{
			proto_errlog( "套接字接收数据发生错误",ERRLOG_MODE);//写日志
			continue;
		}
		
		PLOG("msg deal!!!\n");
		//对报文进行接收处理
		protodata->recvnum++;
		msg.buff = buff;

		show(msg.buff, datalen);
		msg.len = datalen;
		msg.recvtime = time(NULL);
		proto_recvproc(&msg);
	}

	proto_errlog( "UDP数据接收处理线程退出\n",ERRLOG_MODE);//写日志
	return NULL;
}

