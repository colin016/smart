#include "proto.h"
#include "cJSON.h"

extern struct proto_data *protodata;	//引用模块变量

int basehead_len = sizeof(struct pkt_base);
//函数声明
void show(char *buf, int len);

//根据id查找关联人信息节点
relater_inf *find_relater(int id)
{
	return NULL;
}

int parse_pkthead(struct pkt_inf *msg)
{
	char *tmp=msg->buff;
	cJSON *root=NULL,*tmp_hopt=NULL;	

	if(memcmp(tmp,PROTO_BASETAG,4)) //不是以“ZNAF”开头的话，是错误的报文
		return -1;

	msg->basehead = (struct pkt_base *)(tmp+strlen(PROTO_BASETAG)); //移动指针到数据区
	if(msg->basehead->cmd > ZNAFCMD_UPDATE)		//不正确的cmd号
		return -1;
		
		//如果是监控设备的报文，表示出错。
	if(msg->basehead->sort == SORT_POLICEDEV || msg->basehead->sort == SORT_POLICEAPP)
		return -1;
	else //如果从平台过来的报文sid为0，则出错
	{
		if(msg->basehead->sort == SORT_PLATSERVER || msg->basehead->opt & OPT_TRANSFER)
			if(msg->basehead->sid == 0)
				return -1;
	}
	
	root = cJSON_Parse(tmp + basehead_len);
	if(NULL == root)
	{
		PLOG("root parse error!!!\n");
		return -1;
	}
	tmp_hopt = cJSON_GetObjectItem(root, PROTO_HOPTTAG);
	if(NULL != tmp_hopt)
	{
		//如果存在扩展首部，则进行解析
		if(msg->basehead->opt & OPT_TRANSFER)
		{//转发目的地,DID
			msg->did = (char)cJSON_GetObjectItem(tmp_hopt, "DID");
		}

		if(msg->basehead->opt & OPT_ENCRYPT)
		{//密钥序号KEYSEQ
			msg->keyseq = (int)atoi(cJSON_GetObjectItem(tmp_hopt, "KEYSEQ"));	
		}

		if(msg->basehead->opt & OPT_SOURADDR)
		{//要有源ip和端口，SIP和SPORT
			msg->souraddr.sin_addr.s_addr = (unsigned long )atol(cJSON_GetObjectItem(tmp_hopt, "SIP"));
			msg->souraddr.sin_port = (unsigned short int)atoi(cJSON_GetObjectItem(tmp_hopt, "SPORT"));
		}
	}
	//////////////////////////////////////////
	//一下依次解析首部选项////////////////////
	
	//解析源地址扩展首部选项,设置msg->souraddr
	//if(msg->basehead->opt & OPT_SOURADDR)


	//解析加密扩展首部选项,设置msg->keyseq
	//进行解密处理（目前还没有定义，略去）
	//if(msg->basehead->opt & OPT_ENCRYPT)
	//{
	//}
	
	//解析目的did扩展首部选项,设置msg->did
	//检查did是否和本机的id一致，如不一致，报错返回。
	//if(msg->basehead->opt & OPT_TRANSFER)
	//{
	//	msg->did = 0; //需要改进处理
	//}
	
	//设置msg->data，需要改进处理方法
	msg->data = cJSON_GetObjectItem(root, PROTO_DATATAG);
	if(NULL != msg->data)
	{
	//msg->data = strstr(msg->buff, "DATA");
	if(msg->basehead->sort == SORT_PLATSERVER)
		msg->own_node = &protodata->platinf;
	else
		msg->own_node = find_relater(msg->basehead->sid);
	}
		
	cJSON_Delete(root);
	return 0;
}

//封装报文首部
int encap_pkthead(struct pkt_inf *msg, int type)
{
	PLOG("encap_pkthead\n");
	
	strncpy(msg->basehead->tag, PROTO_BASETAG, 4); 
	msg->basehead->ackseq = 0;
	//msg->buff = (char *)msg->basehead;
	//strncpy(msg->buff, msg->basehead, sizeof(struct pkt_base));
	show(msg->buff, DATA_MAXLEN);
    return 0;
}


int proto_deal_test(struct pkt_inf *msg)
{
    printf("proto_deal_test\n");
    return 0;
}

//处理接收到的登陆报文
int proto_deal_login(struct pkt_inf *msg)
{

	
    return 0;
}

int proto_deal_account(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_control(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_deliver(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_find(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_file(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_encode(struct pkt_inf *msg)
{
    return 0;
}

int proto_deal_relate(struct pkt_inf *msg)
{
    return 0;
}

int proto_notsupport(struct pkt_inf *msg)
{
    return 0;
}

/***********************************************************************************
 函数名:proto_deal
 功  能:协议处理函数，判断收到的报文是否合法，调用报文解析函数
 参  数:
        [IN]      struct pkt_inf *msg     报文信息结构体
        [OUT]     无
 返回值:　int
 ***********************************************************************************/
int proto_deal(struct pkt_inf *msg)
{
    //各个协议报文处理指针
	return protodata->proto_proc[msg->basehead->cmd](msg);
}

/***********************************************************************************
 函数名:proto_login_start
 功  能:登录函数                        
 参  数:
        [IN]      source    启动来源
				  0			定时器
				  1			界面
        [OUT]     无
 返回值:　int
 ***********************************************************************************/
int proto_login_start(int source)
{
	cJSON *pJsonRoot = NULL, *pHopt = NULL, *pData = NULL;
	char *username = "13123432422";	//电话-app账号	
	struct pkt_inf *login_pkt_inf ;
	char temp[16] = {0};

	protodata->platinf.loginstatus = LOGINING_STATE;
	login_pkt_inf = (struct pkt_inf *)calloc(1, sizeof(struct pkt_inf));
	login_pkt_inf->buff = (char *)calloc(DATA_MAXLEN, sizeof(char));
	login_pkt_inf->basehead = (struct pkt_base *)calloc(1, sizeof(struct pkt_base));
	if(NULL == login_pkt_inf || NULL == login_pkt_inf->buff || NULL == login_pkt_inf->basehead)
	{
		printf(" calloc error!!!\n");
		return FAIL;
	}

	
	login_pkt_inf->basehead  =  (struct pkg_base *)login_pkt_inf->buff;

	//填充基本首部(登陆特有的部分，公共部分在encap_pkthead中填充)
	login_pkt_inf->basehead->cmd = ZNAFCMD_LOGIN;
	login_pkt_inf->basehead->type = TYPE_LOGIN_QUEST;
	login_pkt_inf->basehead->opt = OPT_REQUEST;
	login_pkt_inf->basehead->sort = SORT_POLICEDEV;
	login_pkt_inf->basehead->sid = 	0;

	PLOG("\n");
	show(login_pkt_inf->buff, DATA_MAXLEN);
	
	
	//json格式封装扩展首部和数据选项
	pJsonRoot = cJSON_CreateObject();
	if(NULL == pJsonRoot)
	{
       printf("\033[40;31mcreate pJsonRoot error!!!\n\033[0m");
	   cJSON_Delete(pJsonRoot);
	   return FAIL;
	}

	if(login_pkt_inf->basehead->opt ==1 || login_pkt_inf->basehead->opt == 2 || login_pkt_inf->basehead->opt == 4 )
	{//*******************这里有点问题，是否所有格式都用string
		pHopt = cJSON_CreateObject();
		if(NULL == pHopt)
		{
			printf("\033[40;31mcreate pHopt error!!!\n\033[0m");
		    cJSON_Delete(pHopt);
			return FAIL;
		}

		if(1 == login_pkt_inf->basehead->opt)
		{
			//转发目的地
				cJSON_AddNumberToObject(pHopt, "DID", login_pkt_inf->did);
		}
		if(2 == login_pkt_inf->basehead->opt)
		{//加密，有密钥序号KEYSEQ
			cJSON_AddNumberToObject(pHopt, "KEYSEQ", login_pkt_inf->keyseq);
		}
		if(4 == login_pkt_inf->basehead->opt)
		{//NAT穿透，有SIP和SPORT
				cJSON_AddStringToObject(pHopt, "SIP", login_pkt_inf->peeraddr.sin_addr.s_addr);
				cJSON_AddStringToObject(pHopt, "SPORT", login_pkt_inf->peeraddr.sin_port);
		}
		cJSON_AddItemToObject(pJsonRoot, PROTO_HOPTTAG, pHopt);
	}

	pData = cJSON_CreateObject();
	if((NULL == pJsonRoot) || (NULL == pData))
    {
       printf("\033[40;31mcreat pData error!!!\n\033[0m");
       cJSON_Delete(pData);
       return FAIL;
    }

    cJSON_AddStringToObject(pData, "USER", username);
    cJSON_AddStringToObject(pData, "SNUM", SOFTWARE_CODE);
    cJSON_AddStringToObject(pData, "SVER", SOFTWARE_VERSION);

    cJSON_AddItemToObject(pJsonRoot, PROTO_DATATAG, pData);
	PLOG("basehead_len= %d\n", basehead_len);
	//strcpy(login_pkt_inf->buff+basehead_len, cJSON_Print(pJsonRoot));
	sprintf(login_pkt_inf->buff+basehead_len, "%s", cJSON_Print(pJsonRoot));
	PLOG("ack = %d\n", login_pkt_inf->basehead->ackseq);
	show(login_pkt_inf->buff, DATA_MAXLEN);

	//发送报文
	proto_sendproc(login_pkt_inf, REMOTE_TYPE_PLAT);
	cJSON_Delete(pJsonRoot);

	free(login_pkt_inf->basehead);
	login_pkt_inf->basehead = NULL;
	free(login_pkt_inf);
	login_pkt_inf = NULL;
	PLOG("proto_login finish\n");
	return 0;
}

//登录后，如果3分钟内双方没有通信信息，要求登录方主动发送保活报文。维持通信关系。登录方主动发送，被登录方及时应答。TYPE=6，没有选项。
//如果保活3次没有成功，则进入重新登录状态。
//如果一个管理APP通过中转登录了监控APP或者监控设备，保活报文也需要中转
//更新发送时间
int proto_keeplive_start(void)
{
	PLOG("keepliv start\n");	

	return 0;
}

int proto_logout_start(void)
{
	
	return 0;
}

int proto_test_start(void)
{
	
	return 0;
}

int proto_register_start(void)
{
	
	return 0;
}

int proto_regoff_start(void)
{
	
	return 0;
}

int proto_update_start(int source)
{
	
	return 0;
}

int proto_query_start(void)
{
	PLOG("query start\n");	
	return 0;
}

int proto_sync_start(int kind, int source)
{
	PLOG("sync start\n");	
	return 0;
}

int proto_alarm_start(struct alarm_inf *msg, int id)
{
	
	return 0;
}

int proto_alarm_startall(struct alarm_inf *msg)
{
	return 0;
	
}

int proto_file_start(void)
{
	
	return 0;
}

//收到异步处理结果，进行后处理。
int proto_async_proc(int code, void *output)
{
	return 0;
}

void show(char *buf, int len)
{
    int i;

    struct pkt_base *bhead = (struct pkt_base *)buf;
    printf("\ntag:%c%c%c%c",bhead->tag[0],bhead->tag[1],bhead->tag[2],bhead->tag[3]);
    printf(" cmd:%d type:%d opt:%d sort:%d",bhead->cmd,bhead->type, bhead->opt,bhead->sort);
    printf(" sid:%d sendseq:%d ackseq:%d",bhead->sid,bhead->sendseq, (int)bhead->ackseq);
    for(i=basehead_len; i<len; i++)
    {
        printf("%c", *(buf+i));
    }
    printf("\n\n");
}

