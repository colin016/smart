﻿#include "proto.h"

extern struct proto_data *protodata;	//引用模块变量


//检查是否需要保活
void check_keeplive(int curtime)
{
	if(protodata->platinf.loginstatus != WORK_STATE)
		return;
	
	//检查最后一次从平台收到报文的时间
    if (protodata->platinf.recvtime + KEEPLIVE_INTERVAL < curtime)
	{
		//向平台发送保活报文
		proto_keeplive_start();
	}
}

//发送报文超时处理，返回0表示报文已清除，1表示报文等待重发, 2表示完成一次发送
int check_sendtimout_proc(sendpkt_node **node, struct sockaddr_in addr)
{
	sendpkt_node *tmp = *node;
	int ret;

	if (tmp->sendcnt > MESSAGE_SEND_COUNT)//超过3次，直接清除
	{
		if (tmp->front == NULL)//删除的节点为头结点
		{
			tmp->next->front = NULL;
			*node = tmp->next;	
		}
		else
		{
			tmp->front->next = tmp->next;
			tmp->next->front = tmp->front;
		}

		free(tmp);
		ret = 0;
	}
	else if (tmp->node.basehead->opt & OPT_REQUEST)//请求报文重发
	{
        	ret = sendto(protodata->sockfd, tmp->node.buff, tmp->node.len,0,(struct sockaddr *)&addr,sizeof(struct sockaddr_in));
		if (ret <= 0)
		{
		    //****************protodata->protocol_callback( "定时器重发报文失败");//写日志
			ret = 1;
		}
		else	
		{
			//更新发送报文数量
			protodata->sendnum ++;
			protodata->sendrenum ++ ;
			//更新报文发送次数
			tmp->sendcnt++;

			ret = 2;
		}
	}
	else
		ret = 1;

	return ret;
}

int timer_snedpkt_timoutproc(sendpkt_node **curnode, struct sockaddr_in addr)
{
    return 0;
}


void check_waitlist(int curtime)  //检查等待重发队列
{
    sendpkt_node *curnode = NULL;
	struct relater_node *relater = NULL;
	int ret;

    pthread_mutex_lock(&protodata->data_lock);
	
	PLOG("check waitlist\n");
	//检查平台超时报文
    if (protodata->platinf.waitnum > 0)
	{
        curnode = protodata->platinf.waitlist;
        while (curnode)
		{
            if (protodata->platinf.sendtime + MESSAGE_TIMEOUT < curtime) //超时报文
			{
                ret = check_sendtimout_proc(&curnode, protodata->platinf.server_addr);
				if (ret == 0)
				{
					//修改等待发送报文的个数
                    protodata->platinf.waitnum -- ;
				}
				else if (ret == 2)
				{
					//更新报文最后一次发送时间和序号
                    protodata->platinf.sendtime = curtime;
                    protodata->platinf.sendseq = relater->node.sendseq;
				}
			}

            curnode = curnode->next;
		}
	}

	//检查APP超时报文
	relater = protodata->userlist;
	while (relater)
	{
        curnode = relater->node.waitlist;
        while (curnode)
		{
            if (relater->node.sendtime + MESSAGE_TIMEOUT < curtime) //超时报文
			{
                ret = timer_snedpkt_timoutproc(&curnode, relater->node.addr);
				if (ret == 0)
				{
					//修改等待发送报文的个数
                    relater->node.waitnum-- ;
				}
				else if (ret == 2)
				{
					//更新报文最后一次发送时间和序号
                    relater->node.sendtime = curtime;
                    relater->node.sendseq = relater->node.sendseq;
				}
			}

            curnode = curnode->next;
		}

		relater = relater->next;
	}

	pthread_mutex_unlock(&protodata->data_lock);
}

//检查登录的关联人是否有超时
void check_relaters(int curtime)
{
	PLOG("check relaters\n");

}

//检查文件传输是否有超时现象
void check_filetrans(int curtime)
{
	PLOG("check filetrans\n");
	//if(protodata->filelist->)
}

//检查是否有延迟处理超时
void check_delaylist(int curtime)
{
	PLOG("check delaylist\n");
	
}

//检查是否需要进行更新
void check_update(int curtime)
{
	PLOG("check update\n");
	proto_update_start(TIMER);
}

//检查是否需要和平台同步关联人
void check_synrelater(int curtime)
{
	
	PLOG("check synrelater\n");
	proto_sync_start(1, 1);

}

//检查是否需要自动登录平台
void check_islogin(int curtime)
{
	PLOG("check islogin\n");
	if(INIT_STATE == protodata->platinf.loginstatus || (curtime - protodata->platinf.sendtime) > LOGIN_CHECK_INTEVAL)
	{//初始状态或者登录超时的时候，自动发送登录请求。
		proto_login_start(TIMER);
	}
}

void *proto_timer(void *arg)//定时器处理线程
{
	unsigned int counter = 0;
	int curtime;

	proto_errlog( "定时器线程开始运行",ERRLOG_MODE);//写日志

	//定时器循环运行
	while (protodata->timer_run)
	{
		curtime = time(NULL);
		//如果未登录平台，检查网络联通状况和自动登录标记发送第一个登录报文
		if (counter % LOGIN_CHECK_INTEVAL == 0)
			check_islogin(curtime);

		//检查平台是否需要保活，发送保活请求报文
        if (counter % KEEPLIVE_INTERVAL == 0)
		{
			if(0 == counter % MESSAGE_SEND_COUNT)
			{
				PLOG("保活三次无应答就重置状态为初始状态\n");
				protodata->platinf.loginstatus = INIT_STATE;
			}
			check_keeplive(curtime);
		}
		//检查发送是否超时没有确认，或者等待重发队列是否超时需要清除。
		if (counter % SEND_CHECK_INTEVAL == 0)
			check_waitlist(curtime);

		//检查是否有关联人登录超时，进行清理
		if (counter % RELATER_CHECK_INTEVAL == 0)
			check_relaters(curtime);

		//检查文件传输是否超时，进行清理
		if (counter % FILETRANS_CHECK_INTEVAL == 0)
			check_filetrans(curtime);

		//检查延迟处理列表是否有超时，进行清理
		if (counter % POSTHANDLE_CHECK_INTEVAL == 0)
			check_delaylist(curtime);

		//检查是否需要自动更新，进行自动更新查询——查询协议
		if (counter % UPDATE_CHECK_INTEVAL == 0)
			check_update(curtime);

		//检查是否需要和服务器同步联系人列表
		if (counter % SYS_CHECK_INTEVAL == 0)
			check_synrelater(curtime);

		counter ++;
		if((UPDATE_CHECK_INTEVAL + 1) == counter)
		{
			counter = 0;
		}
		sleep(1);
	}
	return NULL;
}


