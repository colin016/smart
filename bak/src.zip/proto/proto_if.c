﻿#include "sys.h"
#include "proto.h"

//模块全局变量声明
struct proto_data *protodata = NULL;

//设置默认配置
int get_defaultcfg( void)
{
	struct proto_config  *config;
	
	config = &protodata->cfg;	
	
    strcpy(config->devname, "user");
    strcpy(config->password, "12345678");
    strcpy(config->barcode, "1234567890ABC");
    strcpy(config->identity, "7D503LV100R002208B011");
	config->maxnum = 10;
    config->longitude = 104.06;
    config->latitude = 30.67;
    config->isshow = FALSE;
    config->isauto = FALSE;
    config->iscanceal = FALSE;
    config->isfind = TRUE;
    config->isupdate = TRUE;
    config->issock = TRUE;
    config->ipaddr =inet_addr(PROTO_SERVERIP);
    config->remport = PROTO_PORT;
    config->locport = PROTO_PORT;
	config->deviceid = 0;
    strcpy(config->sysdir, SYSDIR);
    strcpy(config->plugin, "plugin");
    strcpy(config->updatedir, UPDATEDIR);
    strcpy(config->relate, "relate");
    strcpy(config->alarm, "alarm");
    strcpy(config->control, "control");
	
    return 0;
}


//对本模块进行初始化处理，由主框架模块调用
int proto_init(struct KeyValueArray *cfg, moduleCallback callback, struct ModuleInfo *ret)
{
	int retval = 0;

	//首先给全局变量分配空间，清空。
	protodata = (struct proto_data *)malloc(sizeof(struct proto_data));
	if ((NULL == protodata))
	{
        proto_errlog( "申请全局变量内存失败",ERRLOG_MODE);//写日志;
		goto FAILED;
	}
	memset(protodata, 0, sizeof(struct proto_data));
	
	//初始化配置，然后初始化网络和定时器，最后填写返回结构
	get_defaultcfg();
	if(cfg != NULL)
		proto_config(1,cfg);//有配置项时，解析处理配置
	
	//打开套接字
	protodata->sockfd = proto_netinit();
	if (protodata->sockfd < 0)
	{
		PLOG("");
		proto_errlog( "套接字初始化失败\n",ERRLOG_MODE);//写日志
		goto FAILED;
	}
	
	protodata->callback = callback;
	
	//初始化平台信息和关联人信息列表
	srand((unsigned)time(NULL));
	protodata->platinf.sendseq = rand()%100 + 1;
	protodata->platinf.loginstatus = INIT_STATE;
	proto_init_relater();
	
	//注册协议处理函数
	protodata->proto_proc[ZNAFCMD_TEST] = proto_deal_test;
	protodata->proto_proc[ZNAFCMD_LOGIN] = proto_deal_login;
	protodata->proto_proc[ZNAFCMD_ACCOUNT] = proto_deal_account;
	protodata->proto_proc[ZNAFCMD_CONTROL] = proto_notsupport;
	protodata->proto_proc[ZNAFCMD_QUERY] = proto_notsupport;
	protodata->proto_proc[ZNAFCMD_DELIVER] = proto_deal_deliver;
	protodata->proto_proc[ZNAFCMD_FIND] = proto_deal_find;	
	protodata->proto_proc[ZNAFCMD_FILE] = proto_deal_file;	
	protodata->proto_proc[ZNAFCMD_ENCODE] = proto_deal_encode;	
	protodata->proto_proc[ZNAFCMD_RELATE] = proto_deal_relate;	
	protodata->proto_proc[ZNAFCMD_CONTACT] = proto_notsupport;	
	protodata->proto_proc[ZNAFCMD_UPDATE] = proto_notsupport;	

	//初始化访问锁
	pthread_mutex_init(&protodata->data_lock, NULL);
	
	//启动网络数据接收线程
	retval = pthread_create(&protodata->nethandle_thread, NULL, proto_nethandle, &protodata->sockfd);
	if (retval != 0)
	{	
		proto_errlog( "创建网络接收线程失败",ERRLOG_MODE);//写日志
		goto FAILED;
	}
	else
		protodata->nethandle_run = 1;
	
	//启动定时器处理线程
    retval = pthread_create(&protodata->timer_thread, NULL, proto_timer, NULL);
	if (retval != 0)
	{	
		proto_errlog( "创建定时器处理线程失败",ERRLOG_MODE);//写日志
		goto FAILED;
	}
	else
	    protodata->timer_run = 1;	

	//填充ret结构
	strcpy(ret->name,MODULE_NAME);
	ret->type = 0;//模块类型，0表示模块是静态的，1还是可动态升级的。静态的模块只能与主模块一起升级。动态模块可独立升级。
	ret->id = ret->maincode = MODULE_CONTROL;
	ret->subcode = 0;
	ret->version = MODULE_VERSION;
	
	ret->close = proto_close;
	ret->control = proto_control;
	ret->query = proto_query;
	//ret->init = proto_init;
	ret->config = proto_config;
	PLOG("proto_init finish!!\n");	
	return 0;
	
FAILED:
	proto_close();
	return -1;
}

//模块控制，由其他模块调用本模块进行工作的接口
int  proto_control(int sendid, int type, void *input, void *output)
{
	int ret;
	
	PLOG("type = %d\n", type);
	switch(type){
	case 1: //请求发送新报警消息
		ret = proto_alarm_startall((struct alarm_inf *)input);
		break;
	case 2: //通告外设控制结果进行异步处理
		ret = proto_async_proc(*(int *)input, output);
		break;
	case 7: //登录
		ret= proto_login_start(sendid);
		break;
	case 8: //登出
		ret= proto_logout_start( );
		break;
	default:
		printf("正在建设中......\n");
		break;
	}
	return ret;

	
	//来自进程间通信模块：
	//收到设置信息修改配置信息或者启动协议处理

	//来自响应管理模块：
	//启动推送报警信息给服务器和登录的关联人

	//来自外设管理模块
	//启动控制协议后处理进行回复
}

//模块关闭处理，由主框架main模块调用
int  proto_close(void)
{
	//释放各种资源：内存、线程、锁等
	if(protodata)
	{
		if(protodata->timer_run)	//退出已创建定时器线程
			protodata->timer_run = 0;
			
		if(protodata->nethandle_run)
			protodata->nethandle_run = 0;
		
		if(protodata->sockfd>0)
		{
			close(protodata->sockfd);
			pthread_mutex_destroy(&protodata->data_lock);
		}
		
		sleep(1); //等待一秒钟，让所有线程退出
		
		proto_free( ); //释放protodata中所有全局链表内容

		free(protodata);
		protodata = NULL;
	}
	return 0;
}

//对模块的配置进行操作，具体定义如下
//功能要求			type	cfg
//设置修改多个配置项	1	KeyValueArray
//修改配置项为默认值	2	NULL
//查询配置项的当前值	3	KeyValueArray(模块重新申请内存？）
//查询配置项的默认值	4	NULL(模块申请内存？）
int proto_config(int type, void*cfg)
{
	
	return 0;	
}

//提供给主模块的接口
int proto_query(int type, void *input, void *output)
{
	
	return 0;	
}

//为模块提供的通用日志接口
int proto_log(struct loginf *plog, char show)
{
	if(show&1) //打印出来
	{
		printf("LOG:type=%d, user=%s, ret=%d, data=%s\n",plog->type, plog->username, plog->ret, plog->data);
	}
	
	if(show&2) //写入文件
	{
		protodata->callback(MODULE_CONTROL, MODULE_LOG, 1, plog, NULL);
	}
	return 0;	 
}
 
//为模块提供的错误日志接口
int proto_errlog(char *errinf, char show)
{
	if(show&1)
		printf("%s", errinf);
	
	if(show&2)
	{
		struct loginf loginf;
		loginf.type = 1;
		strcpy(loginf.username,"admin");
		loginf.ret = 0;
		strcpy(loginf.data, errinf);
		protodata->callback(MODULE_CONTROL, MODULE_LOG, 1, &loginf, NULL);
	}
	return 0;	
}

//为本模块提供的访问外部其他模块的接口
int proto_execctl(int code, void *input , void *output, char tag)
{
	
	return 0;	
}

//向其他模块通报有更新的接口
int proto_update(int type, char *url)
{
	return 0;
	
}

//初始化关联人信息表
int proto_init_relater(void)
{
	return 0;	
}

//释放所有列表
void proto_free(void)
{
	free(protodata);
	protodata = NULL;

	return;
}
