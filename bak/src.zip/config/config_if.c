﻿#include "config.h"
 
struct config_data *pcfgdata;

//配置模块初始化
//主要工作：将配置文件内容读到内存，并解析，填写cfgdata数据结构
//配置文件格式
/*
#第一行总是表示本配置文件具有多少个配置项。固定长度。
#每行以回车换行结尾，#开头的表示注释,比如：
CONFIGITEM=0001
IPADDR=192.168.1.1
*/
//对ret指针赋值
int config_init(KeyValueArray  *cfg,moduleCallback callback,struct ModuleInfo* ret)
{
	return 0;
	
}

//配置模块查询，按下列要求执行
/*
type	input		output
1	请求号含义：
	0：查询模块状态	0(暂停)/1(工作)
	1：查询消耗内存数	消耗内存字节（int）
	2：查询线程数	线程数
	3：查询打开文件数	打开文件数
	4：查询打开套接字数	打开套接字数

2	请求号：
	1：查询线程具体信息		struct moduleinf{
	2：查询打开文件信息			char name[10]; //线程名称，或者打开文件名，或者套接字类型端口字符串
	3：查询打开套接字信息		int waitnum;  //打开时间
					struct moduleinf *next；}；	查询具体信息*/
int config_query(int type,void *input,void *output)
{
	return 0;
}

//配置模块，按下列要求执行
/*
功能要求	type	cfg
设置修改多个配置项	1	KeyValueArray
设置修改配置项为默认值	2	NULL
查询配置项的当前值	3	KeyValueArray(查询模块提供空间）
查询配置项的默认值	4	KeyValueArray(查询模块提供空间）*/
int config_config(int type,void *cfg)
{
	return 0;
}


//控制本模块，按下列要求执行
/*
type	input	output	说明
1	keyvalue	无	写入修改配置
2	*key	*value	读取选择的配置项
3	无	keyvaluearray	读取配置文件内容
4   keyvaluearray 重新写配置文件内容
5	keyvaluearray 附加配置内容*/
int config_control(int sendid, int type, void *input,void *output)
{
	return 0;
}

//配置模块关闭，释放cfgdata内申请的空间
int config_close(void)
{
	return 0;
}

/*

////////////////////////////////////////////////////////////////////以前的
//实现初始化函数
int config_init(KeyValueArray  *cfg,moduleCallback callback,struct ModuleInfo* ret)
{
    fp = fopen(FILENAME, "r");
	if(fp==NULL)
	{
		fp=fopen("C:\\Users\\芮同\\Documents\\visual studio 2010\\Projects\\配置模块\\配置模块\\sys","r");
	}
	cfg=NULL;
	//config_callback=callback;
    fseek(fp, 0L, SEEK_END);   
    int size = ftell(fp);   
	//printf("配置文件大小为：%d",size);
	c.cfgbuf=(char *)malloc(sizeof(size));
	return 0;
}


//实现查询函数
int config_query(int type,void *input,void *output)
{
	return 0;
}
//实现配置函数
int config_config(int type,void *cfg)//此模块不需要这个接口函数
{
	return 0;
}


//配置文件链表
struct KeyValue *keyValueList(FILE *fp)
{
char lineBuf[SIZE] = {0};  //行缓冲
char *tempP = NULL;        // 临时字符串指针
char *start = NULL;        //键值开始位置
char *end = NULL;          //键值结束位置
char *tempValue = NULL;
struct KeyValueArray *keyValueList,*count,*cfgbuf;
struct KeyValue *head,*q;
head=NULL;
q=NULL;
	struct KeyValue *node;

while(!feof(fp))
	{

	node=(struct KeyValue *)malloc(sizeof(struct KeyValue));
	fgets(lineBuf,SIZE,fp);
	 //是否有"="
        tempP = strchr(lineBuf,'=');//查找字符串linebuf当中首次出现=的位置
        if (tempP == NULL) {
            //没有读取到键值
            continue;
        }
		start=&lineBuf[0];
		node->key=&lineBuf[0];
        while (1) 
		{
            if (*tempP == '=') //一直到找到=再跳出
			{
                break;
            }
            else 
			{
                tempP++;
            }
        }

		end = tempP;
		node->keylen=end-start;
		
	    tempP = strchr(lineBuf, '=');//把等号第一次出现的位置给temP
        //+1超过'='位置
        tempP = tempP + 1;
		node->value=&lineBuf[*(int *)tempP];//问题就在这，无法把字符串解析出来
		node->value=tempP;
 		start=tempP;
        while (1) 
		{
            if (*tempP == '\n') 
			{
                break;
            }
            else 
			{
                tempP++;
            }
        }
        end = tempP;
        //计算出value长度
         node->valuelen= end - start;
		 if(head==NULL)
		{
			head=node;
			q=node;
		}
	else
		{
			q->next=node;
			q=node;

		}
	}
	return head;
}

		void traverse(struct KeyValue *head)//遍历链表
		{
			int i=0;
			struct KeyValue *p;
			p=head;
			while(p!=NULL&&i<=10)//假定先输出十个，结果正确
			{
				i++;
		        printf("%d\n", p->keylen); 
		        p=p->next;
			}
		}


//实现控制函数
int config_control(int sendid,int type,void *input,void *output)
{	
	struct KeyValue *in = (struct KeyValue *)input;
	switch(type)
	{
	case 1:
		{
			int flag=0;
			fp = fopen(FILENAME, "a");
			try
			{
				if(fp==NULL)
				{
					flag=1;
					throw(flag);
				}
				fprintf(fp,"$%s=%s\n",in->key,in->value);
			}
			catch(Exception)
			{
				printf("Can not write file %s",FILENAME);
				exit(1);
			}
			fflush(fp);
			fclose(fp);
			return flag;
			break;
		}
	case 2:
		{
			int  flag=0; 
            char buffer[SIZE]; 
            //FILE *file=fopen(fp,"r"); 
			try
		   { 
			if(fp==NULL) 
            { 
                flag=1; 
                throw(flag); 
			 } 
           else
           { 
           while(fgets(buffer,SIZE,fp)!=NULL) 
           { 
				int i=0,j=0,len=strlen(in->key); 
                while(buffer[i]!='\0') 
				{ 
					 if(buffer[i]=='$'&&buffer[i+len+1]=='=') 
					 { 
						 j=i+len+2; 
							while(buffer[j]!='\0'&&buffer[j]!=';') 
							{ 
								 int h=0; 
								 if(buffer[i+1]==in->key[i]) 
								{ 
									//printf("%c",buffer[j]); 
									in->value[j-i-len-2]=buffer[j]; 
								} 
									j++; 
						    } 
							break; 
					 } 
						 else if(buffer[i]=='/'&&buffer[i+1]=='/'||buffer[i]==';') 
						{ 
							break; 
					    } 
						i++; 
				} 
           } 
         }  
		 } 
			catch(Exception) 
			 { 
			    flag=2; 
				fclose(fp); 
				printf("can't open file %s",FILENAME); 
				exit(1); 
			 } 
			fflush(fp); 
			fclose(fp);  
		    return flag; 
			break;
}
	case 3:
		{
			 char ch;
			 if((fp=fopen(FILENAME,"r"))==NULL)
  			 {
     				printf("\nSorry, Can't open the file! @_@\n");
    				exit(0);
   			 }
 			 else
   			 {
     				while((ch=fgetc(fp))!=EOF)
     				{  
					printf("%c",ch);  
				    }
     			fclose(fp);
  			 }
			break;
		}
	default:
			printf("please enter again choose 1 or 2 or 3\n");
			scanf("%d\n",&type);
			return 0;
		    break;
	
	}
	return 0;
}

int config_close(void)
{
	free(c.cfgbuf);
	return 0;//返回给操作系统，表示函数正常结束。
}


int getFileSize(char * strFileName)    
{   
    FILE * fp = fopen(FILENAME, "r");   
    fseek(fp, 0L, SEEK_END);   
    int size = ftell(fp);   
    fclose(fp);  
	printf("%d",size);
    return size;   
}检测文件大小函数 


void main()
{
	//struct KeyValue *keyValueList1;
	int config_init(KeyValueArray  *cfg,moduleCallback callback,struct ModuleInfo* ret);
	int config_query(int type,void *input,void *output);
	int config_config(int type,void *cfg);
	//keyValueList1=keyValueList(fp);
    //traverse(keyValueList1);
	int config_control(int sendid,int type,void *input,void *output);
	int config_close(void);
	getchar();
	getchar();
}*/
