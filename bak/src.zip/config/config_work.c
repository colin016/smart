﻿#include "config.h"

extern struct config_data *pcfgdata;

//获取配置项数量，就是解析配置文件的第一行
int cfg_getcount( void)
{
	return 0;
}

//将配置文件内容读到缓冲区，事先要给buf分配合适的空间
int cfg_getfile( char *buf)
{
	return 0;
}

//更新一个配置项		
int cfg_update(KeyValue *cfg)
{
	return 0;
}

//将指定项数的配置内容写入配置文件
int cfg_putfile(KeyValueArray  *cfg, int from, int to)
{
	return 0;
}

//获得一个配置的结果			
int cfg_query(char *key, KeyValue *cfg)
{
	return 0;
}
