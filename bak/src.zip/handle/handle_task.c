﻿//handle_task.c
//实现监控要求的管理
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "handle.h"
extern struct handle_data *phdata;

//检查是否有监控任务文件，有则读出文件内容，对handledata.task链表赋值
int handle_taskinit(void)
{

	return 0;
}

//根据handledata.task链表内容，重新写监控任务文件
int handle_taskwrite(void)
{
	return 0;	
}

//查找任务编号为id的监控任务内容，当id=-1时，返回所有任务链表
struct	demand	* handle_taskquery(int id)
{
	return NULL;	
}

//删除一个监控任务
int handle_taskdel(int id)
{
	return 0;
}

//更新监控任务
int handle_taskmod(struct demand *task)
{
	return 0;
}

//添加一个任务
int handle_taskadd(struct demand *task)
{
	return 0;
}

//根据动态库支持，更新任务文件，去掉不支持的监控任务项
int handle_taskupdate(void)
{
	return 0;
}
