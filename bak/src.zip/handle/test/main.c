﻿#include <stdio.h>
#include "handle.h"

int main_callback(int sendid, int recvid, int type, void *input, void *output);

int main()
{
	int ret = 0,i;
	struct ModuleInfo modinf;
	char Buffer[40];

	memset(&modinf,0,sizeof(struct ModuleInfo));

	ret = handle_init(NULL, main_callback, &modinf);
	
	if(ret <= -1)
	{
		printf("初始化失败，程序退出\n");
		return -1;
	}
	
	while(1)
	{
		//提示信息
		puts("\n选择要测试的功能:");
		puts("1: 查询动态库支持的监控任务");		
		puts("2: 显示全部监控任务\n");
		puts("quit: 退出程序\n");

		//等待用户输入
		fgets(Buffer,sizeof(Buffer),stdin);
		if(!strlen(Buffer)) //如果没有输入信息，继续循环
			continue;
			
		if(Buffer[0] == '1')
			i = 1;
		else if(Buffer[0] == '2')
			i = 2;
		else
		{
			//程序的一个退出条件
			if(!strncmp(Buffer, "quit", 4)) 
			{
				break;
			}
			else
			{
				printf("输入错误：%s", Buffer);
				continue;
			}			
		}
		
		//执行用户选择
		switch(i)
		{
		case 1:
		{
			int num = modinf.control(0,4,NULL,NULL);
			if(num > 0)
			{
				struct task_inf *buf = (struct task_inf *)malloc(num * sizeof(struct task_inf));
			
				modinf.control(0, 4, NULL, buf);
				for(i = 0; i<num; i++)
				{
					printf("Task NO:%d, %s\n", buf[i].sort, buf[i].tasktip);
				}
				
				free(buf);
			}
		}
			break;
		case 2:
		{
			int type=-1;
			struct task_inf *buf;
			modinf.control(0, 11, &type, &buf);
		}
			break;
		default:
			printf("ERROR!\n");
		}
		
	}	
	
	//程序退出处理
	modinf.close( );

    return 0;
}


int main_callback(int sendid, int recvid, int type, void *input, void *output)
{
    int ret = 0;

    printf("callback is called!\n");
	printf("sendid=%d recvid=%d type=%d\n",sendid, recvid, type);
	
    return ret;
}
