#include <stdio.h>


void (*cb)(int type, void* msg);

//��̬��ӿں���
int init(struct demand *head, void (*callback)(int type, void* msg))
{
	cb = callback;
	printf("enter init( )......\n");
	return 0;	
}

int query(int type, int *num)
{
	printf("enter query( )......\n");
	return 0;
}

int control(int type, void *in, void *out)
{
	printf("enter control( )......\n");
	return 0;
}

int close(void)
{
	printf("enter close( )......\n");
	return 0;
}
