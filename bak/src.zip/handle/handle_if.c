﻿#include "handle.h"

//模块全局变量声明
struct handle_data *phdata;

//设置默认配置
int handle_defaultcfg( void)
{
    return 0;
}


//对本模块进行初始化处理，由主框架模块调用
int handle_init(struct KeyValueArray *cfg, moduleCallback callback, struct ModuleInfo *ret)
{
	return 0;
}

//模块控制，由其他模块调用本模块进行工作的接口，详细要求见设计说明书38页前后
int  handle_control(int sendid, int type, void *input, void *output)
{
	return 0;
}

//模块关闭处理，由主框架main模块调用
int  handle_close(void)
{

	return 0;
}

//对模块的配置进行操作，具体定义如下
//功能要求			type	cfg
//设置修改多个配置项	1	KeyValueArray
//修改配置项为默认值	2	NULL
//查询配置项的当前值	3	KeyValueArray(模块重新申请内存？）
//查询配置项的默认值	4	NULL(模块申请内存？）
int handle_config(int type, void*cfg)
{
	
	return 0;	
}

//提供给主模块的接口
int handle_query(int type, void *input, void *output)
{
	
	return 0;	
}

