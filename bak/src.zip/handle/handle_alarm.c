﻿//实现对报警消息的访问管理

#include <sys/time.h>
#include <signal.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

#include "handle.h"
extern struct handle_data phdata;

//初始化报警消息文件
//如果文件存在，则清空文件内容；如果文件不存在，则创建文件。
int handle_alarminit( void )
{

	return 0;
}

//将报警消息备份到指定的文件中去
int handle_alarmbak(char *file)
{
	int ret = 0;

	return ret;
}


//查询报警消息，将结果保存到备份文件中
int handle_alarmquery(struct alarm_query *query, char *file)
{
	return 0;
}

//写入一条报警信息，当报警消息条数超过最大值时，备份前面的，重新生成新文件。
int handle_alarmwrite(struct alarm_inf *alarminf)
{
	return 0;
}

//查询报警消息，将结果读入内存中,buf是存放的数组指针，
//由调用者申请内存，需要读的条数在query中。如果buf为NULL，则仅返回的int是实际符合要求的条数。
int handle_alarmload(struct alarm_query *query, struct alarm_inf *buf)
{
	return 0;
}