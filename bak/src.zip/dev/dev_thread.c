﻿#include "dev.h"

extern struct proto_data *protodata;	//引用模块变量

//添加一个新的IO到事件处理线程中
int dev_addevent(struct media_if *medinf)
{
	return 0;
}

//从事件处理线程中删除一个接口
int dev_delevent(struct media_if *medinf)
{
	return 0;
}


void *dev_recvhandle(void *arg)
{
	int *ret = arg;

	return ret;	
}
