﻿#include "dev.h"

struct media_if *med_inf;

int med_control(int type, void *input, void *output)  //介质控制函数。
{
	return 0;
}

int med_init(struct media_if *med_inf) //初始化函数指针
{
	return 0;
}

int med_close(void) //关闭函数指针
{
	return 0;
}

int med_check(void)//介质可用性检查函数指针
{
	return 0;
}
int med_send(char *msg, int len)//介质发送信息函数
{
	return 0;
}

int med_recv(char *buf, int len)//接收处理函数,实现有关处理协议及子接口控制
{
	return 0;
}
