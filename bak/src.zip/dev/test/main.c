﻿#include <stdio.h>
#include "dev.h"

int main_callback(int sendid, int recvid, int type, void *input, void *output);

int main()
{
	int ret = 0,i;
	struct ModuleInfo modinf;
	char Buffer[40];

	memset(&modinf,0,sizeof(struct ModuleInfo));

	ret = dev_init(NULL, main_callback, &modinf);
	
	if(ret == -1)
	{
		printf("初始化失败，程序退出\n");
		return -1;
	}
	
	while(1)
	{
			//得到要发送的信息字符串
		puts("\n选择送到服务器的报文类型:");
		puts("1: 登录报文");		
		puts("2: 登出报文\n");
		puts("quit: 退出程序\n");

		fgets(Buffer,sizeof(Buffer),stdin);
		if(!strlen(Buffer)) //如果没有输入信息，继续循环
			continue;
			
		if(Buffer[0] == '1')
			i = 1;
		else if(Buffer[0] == '2')
			i = 2;
		else
		{
			//程序的一个退出条件
			if(!strncmp(Buffer, "quit", 4)) 
			{
				break;
			}
			else
			{
				printf("输入错误：%s", Buffer);
				continue;
			}			
		}
		switch(i)
		{
		case 1:
			modinf.control(0, 7, NULL, &ret);
			break;
		case 2:
			modinf.control(0, 8, NULL, NULL);
			break;
		default:
			printf("ERROR!\n");
		}
		
	}	
	
	modinf.close( );

    return 0;
}


int main_callback(int sendid, int recvid, int type, void *input, void *output)
{
    int ret = 0;

    printf("callback is called!\n");
	printf("sendid=%d recvid=%d type=%d\n",sendid, recvid, type);
	
    return ret;
}
