﻿#include "dev.h"

extern struct proto_data *protodata;	//引用模块变量


void *dev_timer(void *arg)
{
	char *ret = arg;
	
	return ret;	
}
