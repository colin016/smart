#include "dev.h"

extern struct dev_data *devdata;	//引用模块变量

//添加一个设备
int dev_add(struct ext_dev *node)
{
	return 0;
}

//删除一个设备
int dev_del(int devid)
{
	return 0;
}

//更新一个设备表内容
int dev_update(struct ext_dev *node)
{
	return 0;
}

//释放所有的设备表信息
int dev_clear( )
{
	return 0;
}