﻿#include "proto.h"

struct ext_dev *extdev;

int device_control(int type, char *input, int ilen, char *output, int olen)  //设备控制函数，针对已有设备类型，定义一个通用操作函数。input是输入指令；output是输出信息；在实现过程中，每个基本设备定义有type和input。
{
	return 0;
}

int device_init(struct ext_dev *extdev)//初始化函数指针
{
	return 0;
}

int device_close(void) //关闭函数指针
{
	return 0;
}

int device_keepalive(void)//保活函数指针
{
	return 0;
}