﻿#include "dev.h"

extern struct dev_data *devdata;	//引用模块变量

//添加一个介质
int devmed_add(struct media_if *node)
{
	return 0;
}

//删除一个介质
int devmed_del(char type, char subtype)
{
	return 0;
}

//更新一个介质表内容
int devmed_update(struct media_if *node)
{
	return 0;
}

//释放所有的介质表信息
int devmed_clear( )
{
	return 0;
}