﻿#ifndef DEVICE_H_
#define DEVICE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h> 
#include <time.h>
#include "debug.h"
#include "sys.h"

//模块用到的数据结构定义
//介质接口定义
struct media_if
{
	char type;              /*介质类型*/
	char subtype;				//介质子类型
	char status;            //0不可用，1正常可用
	char name[30];			/*媒介名称*/
	int fd;				//介质打开的标识符
	char *buf;			//接收信息缓冲区
	int len;			//当前接收信息长度

	void *para;               /*每种介质参数，比如以太网有ip，串口有波特率等*/
	int (*control)(struct media_if *medinf, int type, void *input, void *output);  //介质控制。
	int (*init)(struct media_if *medinf); //初始化函数指针
	int (*close)(struct media_if *medinf); //关闭函数指针
	int (*check)(struct media_if *medinf); //介质可用性检查函数指针
	int (*send) (struct media_if *medinf, char *msg, int len); 	//介质发送信息函数
	int (*recv)(struct media_if *medinf, char *buf, int len);		//接收处理函数

	int	devnum;				//该介质连接的设备数量
	struct ext_dev *list;			//该介质上存在的外设链表
	struct media_if  *next;       /*下一个媒介*/
};

//外接设备定义
struct ext_dev
{
	short	dev_type;		//设备类型，一个设备可以是多个类型的复合设备。
	int		devid;			/*设备编号*/
	char	devname[32];		/*设备名称*/
	char	location[32];		/*设备安装位置*/
	int		recvtime;			//最近收到设备信息时间
	short	status;			/*设备状态，1 运行状态，0失联状态*/

	int (*control)(struct ext_dev *extdev, int type, char *input, int ilen, char *output, int olen);  //设备控制函数，针对已有设备类型，定义一个通用操作函数。input是输入指令；output是输出信息；在实现过程中，每个基本设备定义有type和input。
	int (*init)(struct ext_dev *extdev); //初始化函数指针
	int (*close)(struct ext_dev *extdev); //关闭函数指针
	int (*keepalive)(struct ext_dev *extdev); //保活函数指针

	union private 
	{ 
		char	buffer[4]; //设备特别数据结构，比如保存传感器的最近信息，与设备有关。
		int		readdata;
	}data;

	struct media_if *media;		/*指向媒介*/
	struct ext_dev	*next;		//设备链表
	struct ext_dev	*ifnext;		//同介质设备链表
};

//控制要求表
struct ctrl_inf 
{
	int	devid;			/*设备编号*/
	int	requestid;		//请求者id
	pthread_mutex_t lock;	//互斥锁
	struct ctrl_inf *next	;	//下一个节点
};

struct dev_data
{
	struct ctrl_inf	*ctllist;
	struct media_if *medlist;
	struct ext_dev *devlist;
	moduleCallback	callback;		//访问其他模块功能的回	
};
	
//外部接口函数定义	
int dev_init(struct KeyValueArray  *cfg, moduleCallback callback, struct ModuleInfo* ret);
int dev_close(void);
int dev_query(int type, void *input, void *output); 
int dev_config(int type, void*cfg); 
int dev_control(int sendid, int type, void * input, void * output);

//内部接口函数定义
//设备和介质收到信息后的通知处理
int devnotify(struct ext_dev *extdev, int type, void *msg);

//线程处理函数定义
void *dev_timer(void *arg);
void *dev_recvhandle(void *arg);

//中间处理函数定义
int dev_recvproc(char *msg);
int dev_sendproc(char *msg);

#endif
