#include <stdio.h>       
#include <string.h>
#include <stdlib.h>
#include "sys.h"

#define CONFIG_FILE	"../sys/config.ini"

struct config_data
{
	KeyValueArray	cfginf;
	int filesize;	//配置文件大小，如果有异常，大小为0;
	FILE* fopen;	//打开的配置文件指针，如果没有打开，为NULL
};

//外部接口函数
int config_init(KeyValueArray  *cfg,moduleCallback callback,struct ModuleInfo* ret);
int config_query(int type,void *input,void *output);
int config_config(int type,void *cfg);
int config_control(int sendid, int type, void *input,void *output);
int config_close(void);

//内部接口函数
int cfg_getcount( void);  				//获取配置项数量
int cfg_getfile( char *buf); 			//将配置文件内容读到缓冲区
int cfg_update(KeyValue *cfg);			//更新一个配置项
int cfg_putfile(KeyValueArray  *cfg, int from, int to); 			//将配置内容写入配置文件
int cfg_query(char *key, KeyValue *cfg); 	//获得一个配置的结果
