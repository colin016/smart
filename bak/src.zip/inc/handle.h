﻿#ifndef HANDLE_H
#define HANDLE_H

#include "dev.h"
#include "debug.h"

//动态库状态
#define DLL_UNLOAD		0
#define DLL_RUNNING		1
#define DLL_PAUSE		2
#define DLL_ERROR		-1
#define MAX_DEMAND		10

//资源位置
#define DLL_FILE	"../sys/smartdll.so"
#define TASK_FILE	"../task/task.txt"
#define ALARM_FILE	"../data/alarm.txt"

//设备控制结构
struct devctl
{
	struct	ext_dev *dev;	//控制设备

	char 	instruct[22]; 	//控制指令，调用dev.control()完成。
	char 	type;			//采集的信息类别
	char 	ilen;			//指令长度
	struct devctl *next;	//构成链表
};

//界面通过获取这个信息给用户选择合适的参数组，信息由智能处理动态库给出
struct para_inf
{
	int sort;	//监控任务类型
	int index;	//任务支持参数组编号
	char *paratip;	//参数组提示信息
};

//界面通过获取这个信息给用户选择一个合适的任务，信息由智能处理动态库给出
struct task_inf
{
	int sort;		//监控任务类型
	char *tasktip;	//任务提示信息
};

//工作任务定义
//一个动态库是否支持
struct demand{
	int		id;			//监控任务编号，从1开始，自动生成唯一编号
	
	char	sort;		//监控类型，定义具体处理分析方法的依据，可以不断增加，需要动态库支持。
	short	version;	//监控要求版本号,本数据结构可能经常配合动态库改进，需要版本号区别
	
	char	name[32]; 	//监控任务名称，人工自定义
	char	level;		//报警级别，人工自定义数据
	short	type;		//报警类别，人工自定义数据

	char 	*file;	//任务需要的文件路径或者文件名
	char	filetype;	//任务需要的文件类型
	int 	index;	//监控分析参数集编号
	
	struct devctl	*inlist;	//采集信息控制列表
	struct devctl	*outlist;	//控制响应定义列表，对设备操作指令等
	
	int		num;		//自启动以来，本监控任务产生符合条件的监控信息数量。
	struct	demand	*next;	/*监控要求任务链*/
};

//动态库信息
struct dllinfo 
{
	char dllname[20];
	void *handle;
	char status;
	
	int (*init)(struct demand *head, void (*callback)(int type, void* msg));
	int (*control)(int type, void *in, void *out); //主要接口函数
	int (*query)(int type, int *num);
	int (*close)(void);
	void (*callback)(int type, void* msg);
};

//报警消息数据结构
struct alarm_inf
{
	char type;	//报警类型
	char level;	//报警级别
	int  time;	//报警时间
	char attach[64]; //附件文件名,以分号分开
}; 

struct alarm_query
{
	char sort;	//查询条件类型：1：类型，2：级别，4，日期
	char type;	//查询的关键字，
	char level;	//查询的级别
	unsigned char num; //最大信息条数
	int from;	//查询日期起始值，
	int to;		//查询日期截止日，
	
};

//模块数据结构
struct handle_data
{
	struct	dllinfo	dinfo;
	struct	demand	*task;
	KeyValue 	*cfgList;
	int tasknum;
	int status;
	moduleCallback		callback;		//访问其他模块功能的回
};

//外部接口函数定义	
int handle_init(struct KeyValueArray  *cfg, moduleCallback callback, struct ModuleInfo* ret);
int handle_close(void);
int handle_query(int type, void *input, void *output); 
int handle_config(int type, void*cfg); 
int handle_control(int sendid, int type, void * input, void * output);



#endif
