﻿#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h> 
#include <time.h>
#include <dirent.h>  
#include <stdarg.h>   
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>  
#include <net/if.h>  
#include <arpa/inet.h>
#include "sys.h"
#include "handle.h"

//模块用到的常量定义

//定时器常量定义
#define CONNECT_CHECK_INTEVAL	10  //连接检测时间间隔 单位: 秒
#define LOGIN_CHECK_INTEVAL 	30  //登录检测时间间隔
#define SEND_CHECK_INTEVAL 		3  //报文发送重发和超时检测时间间隔
#define RELATER_CHECK_INTEVAL	10  //关联人登录超时检测时间间隔
#define FILETRANS_CHECK_INTEVAL	3  //文件传输检测时间间隔
#define POSTHANDLE_CHECK_INTEVAL	3  //延时处理检测时间间隔
#define UPDATE_CHECK_INTEVAL	600  //更新检测时间间隔
#define SYS_CHECK_INTEVAL		300  //关联人同步检测时间间隔

//保活常量定义
#define KEEPLIVE_INTERVAL			180		// 保活超时时长，单位: 秒
#define KEEPLIVE_BREAK_TIMES		3		// 连续KEEP_BREAK_TIMES 次检测到没有保活，则认为断开连接
#define MESSAGE_TIMEOUT				3		//发送报文等待应答的超时时间，单位：秒
#define MESSAGE_SEND_COUNT			3		//发送报文最大次数

//协议常量定义
#define PROTO_BASETAG	"ZNAF"		/*智能安防基本首部头*/
#define PROTO_HOPTTAG	"HORT"		/*智能安防扩展首部*/
#define PROTO_DATATAG	"DATA"		/*智能安防数据选项*/
#define PROTO_PORT		5678		/*通信固定端口*/
#define PROTO_SERVERIP		"127.0.0.1"

//命令号定义
#define ZNAFCMD_TEST		0		/*连通测试报文*/
#define ZNAFCMD_LOGIN		1		/*连通管理协议*/
#define ZNAFCMD_ACCOUNT		2		/*账号管理协议*/
#define ZNAFCMD_CONTROL		3		/*控制协议*/
#define ZNAFCMD_QUERY		4		/*数据查询协议*/
#define ZNAFCMD_DELIVER		5		/*消息传递协议*/
#define ZNAFCMD_FIND		6		/*局域网发现协议*/
#define ZNAFCMD_FILE		7		/*文件数据传递协议*/
#define ZNAFCMD_ENCODE		8		/*加密协议*/
#define ZNAFCMD_RELATE		9		//关联人管理协议	
#define ZNAFCMD_CONTACT		10		//联系人管理
#define ZNAFCMD_UPDATE		11		//升级查询
#define ZNAFCMD_MAXNUM		12		//协议数量

/*报文类型定义*/
#define TYPE_LOGIN_QUEST            1		/*登录请求报文*/
#define TYPE_LOGIN_REPLY            2		/*登录应答报文*/
#define TYPE_LOGIN_CONFIRMQUEST		3		/*验证请求报文*/
#define TYPE_LOGIN_CONFIRMREP		4		/*验证应答报文*/
#define TYPE_LOGIN_KEEPQUEST		6		/*保活请求报文*/
#define TYPE_LOGIN_KEEPREPLY		7		/*保活应答报文*/

#define TYPE_ACCREG_QUEST		1		/*申请账号请求报文*/
#define TYPE_ACCREG_REPLY		2		/*申请账号应答报文*/
#define TYPE_ACCMOD_QUEST		3		//修改帐号请求
#define TYPE_ACCMOD_REPLY		4		//修改帐号应答
#define TYPE_ACCKILL_QUEST		5		//注销帐号请求
#define TYPE_ACCKILL_REPLY		6		//注销帐号应答

#define TYPE_CONTROL_QUEST			1		/*控制请求报文*/
#define TYPE_CONTROL_REPLY			2		/*控制应答报文*/

#define TYPE_QUERY_QUEST			1		/*数据查询请求报文*/
#define TYPE_QUERY_REPLY			2		/*数据查询应答报文*/

#define TYPE_DELIVER_QUEST			1		/*消息推送请求报文*/
#define TYPE_DELIVER_REPLY			2		/*消息推送应答报文*/
#define TYPE_DELIVER_GROUP			3		/*消息推送请求报文*/

#define TYPE_FIND_QUEST			1		/*局域网广播通报报文*/
#define TYPE_FIND_REPLY			2		/*监控端应答报文*/

#define TYPE_FILE_QUEST			1		/*文件传输请求报文*/
#define TYPE_FILE_REPLY			2		/*文件传输应答报文*/
#define TYPE_FILE_STOP			3		/*文件传输终止报文*/

#define TYPE_RELATE_QUEST		1		/*关联账号请求报文*/
#define TYPE_RELATE_REPLY		2		/*关联账号应答报文*/
#define TYPE_RELOUT_QUEST		3		/*脱联账号请求报文*/
#define TYPE_RELOUT_REPLY		4		/*脱联账号应答报文*/
#define TYPE_RELINF_QUEST		5		/*脱联/关联账号通知请求报文*/
#define TYPE_RELINF_REPLY		6		/*脱联/关联账号通知应答报文*/
#define TYPE_RELGET_QUEST		7		/*获取关联账号请求报文*/
#define TYPE_RELGET_REPLY		8		/*获取关联账号应答报文*/
#define TYPE_RELSYN_QUEST		7		/*同步关联账号请求报文*/
#define TYPE_RELSYN_REPLY		8		/*同步关联账号应答报文*/

//软件定义
#define SOFTWARE_CODE		"12345678"					/*软件编号*/
#define SOFTWARE_VERSION	"011103"					/*软件版本号*/
#define DATA_MAXLEN			1400	/*报文数据最大长度*/
#define DATA_HEADLEN		20	/*报文基本首部长度*/

//设备类型
#define SORT_USERAPP	0
#define SORT_POLICEAPP	1
#define SORT_POLICEDEV	2
#define SORT_PLATSERVER	3

//选项宏定义
#define OPT_TRANSFER	1
#define OPT_ENCRYPT		2
#define OPT_SOURADDR	4
#define OPT_REQUEST		8
#define OPT_RESPONSE	16
#define OPT_NONJSON		32

//日志写入模式
#define ERRLOG_SHOW				1
#define ERRLOG_FILE				2
#define ERRLOG_ALL				3
#define ERRLOG_NONE				0
#define ERRLOG_MODE				ERRLOG_SHOW

//报文目标类型
#define REMOTE_TYPE_APP		0	//管理APP
#define REMOTE_TYPE_PLATAPP	1	//通过平台转发的APP
#define REMOTE_TYPE_PLAT	2	//平台

//自定义错误号
#define ERROR_PACKET_FORMAT		1	//报文格式错误
#define ERROR_OPTION_ITEM		2	//有错误的选项
#define ERROR_RIGHT_LIMIT		3   //权限不够
#define ERROR_ACCOUNT_NO		4	//帐号不存在或者被禁止
#define ERROR_FILE_NOEXIST		5	//制定的文件不存在
#define ERROR_MEMORY_OUT		6	//没有足够的内存

//系统错误定义
#define ERROR_CREATE_SOCK		4801001
#define ERROR_BIND_SOCK			4801002
#define ERROR_LISTEN_SOCK		4801003
#define ERROR_ACCEPT_SOCK		4801004
#define ERROR_CONNECT_SOCKL		4801005
#define ERROR_RECV_SOCK			4801006
#define ERROR_SEND_SOCK			4801007
#define ERROR_NET_BREAK			4801008

//模块定义
#define MODULE_MAIN		0
#define MODULE_CFG		1
#define MODULE_LOG		2
#define MODULE_ATTACH	3
#define MODULE_SMART	4
#define MODULE_FACE		5
#define MODULE_CONTROL	6

//模块属性定义
#define MODULE_NAME		"RemoteControl"
#define MODULE_VERSION	1

//状态定义
#define INIT_STATE		0
#define LOGINING_STATE	1
#define VALIDAT_STATE	2
#define WORK_STATE		3

//****************************************************
//source来源（0-定时器, 1-界面）
#define TIMER 0
#define UI	  1

#define SUCCCESS          0     
#define FAIL              -1


#define TRUE 1
#define FALSE 0

#define SYSDIR          "../sys"
#define UPDATEDIR       "../bak"

//1、配置信息，将上面保存在文件中的信息调入内存便于随时使用。
struct proto_config 
{
	char devname[20];	//设备名称
	char password[20];	//设备登录平台密码
	short int maxnum;		//最大关联人数量
	char barcode[20];	//设备条形码
	char identity[30];	//设备唯一标识符
	int deviceid;		//设备注册后的id，没有则为0

	float longitude;	//设备位置——经度
	float latitude;		//设备位置——纬度

	char isshow;	//是否在界面显示密码
	char isauto;	//是否自动登录平台服务器
	char iscanceal;	//是否在平台上已经注销
	char isfind;	//是否支持局域网自动发现协议
	char isupdate;	//是否自动更新前端设备软件
	char issock;	//网络是否连通

	long ipaddr;		//服务器IP地址
	unsigned short remport;	//服务器登录端口
	unsigned short locport;	//本地通信绑定端口	

	char sysdir[20];	//系统文件目录名
	char plugin[30];	//插件文件名
	char updatedir[20];	//自动升级程序下载目录
	char relate[10];	//关联人文件名
	char alarm[10];		//报警消息文件名
	char control[10];	//远程控制日志文件名
};


struct pkt_base
{
    char tag[4];
	unsigned char cmd;
	unsigned char type;
	unsigned char opt;
	unsigned char sort;
	int sid;
	int sendseq;
	int ackseq;	
};

typedef struct pkt_inf  //协议报文信息
{
	char	*buff;
	int 	len;
	int	recvtime;
	struct sockaddr_in peeraddr;

	struct pkt_base *basehead;

	char	did;
	int		keyseq;
	struct sockaddr_in souraddr;	

	char *data;
	void *own_node;
}pkt_inf;


typedef struct sendpkt_node
{
	struct pkt_inf	node;	//发送的报文
	unsigned char	sendcnt;//最近报文重发次数

	struct sendpkt_node *front;
	struct sendpkt_node *next;
}sendpkt_node;

typedef struct plat_inf
{
	int logintime;	//最近登录平台时间
	int	loginstatus;	//登录状态
	struct sockaddr_in server_addr;			/*保存服务器的网络，根据配置得到*/

	int update;			//最近检查更新的时间
	int syntime;		//最近检查同步关联人的时间
	
	int recvseq;		//最近收到的平台报文序号	
	int recvtime;		//最近收到的平台报文时间
	int sendtime;		//最近发送给平台报文时间
	int sendseq;		//最近发送给平台报文序号

	int waitnum;		//等待重发报文数量
	struct sendpkt_node *waitlist;	//等带重发报文列表			
}plat_inf;

typedef struct relater_inf
{
	char username[20];	//关联人登录名称
	char password[20];	//登录密码
	char right;			//用户权限
	char status;		//用户状态
	
	struct sockaddr_in addr;	

	int logintime;		//登录时间
	int	id;				//关联人的id，中转时用

	int recvseq;		//最近收到关联人报文序号	
	int recvtime;		//最近收到关联人报文时间
	int sendseq;		//最近发送关联人报文序号	
	int sendtime;		//最近发送关联人报文时间

	int waitnum;		//等待重发报文数量
	struct sendpkt_node *waitlist;	//等带重发报文列表
}relater_inf;

struct relater_node
{
	struct relater_inf 	node;
	struct relater_node *next;
};

typedef struct file_inf
{
	char	filename[20];	//文件名
	FILE 	*fp;			//文件打开指针
	char 	MD5[32];		//文件的md5值
	int 	size;			//文件的大小
	int		curpos;			//文件当前指针位置
	char 	type;			//文件类型：0报警消息附件 1插件文件 2下载的更新文件
	int 	time;			//最近操作文件时间，便于定时器检查关闭
	pthread_mutex_t		file_lock; //访问文件信息锁
}file_inf;

struct file_node
{
	struct file_inf		node;
	struct file_node 	*next;
};

//后处理任务节点信息
struct posthandle_node
{
	int time;	//处理时间
	int feature;	//该任务的特征符号
	char source;	//任务来源：>=0界面，-1网络
	char cmd;	//网络执行任务的报文命令
	char type;	//网络执行任务的报文类型
	char sort;	//任务执行者类别：>0 程序；<0 表示执行模块
	int dstid;	//任务执行者id
	int srcid;	//任务请求者id
	struct posthandle_node *next;	
};

//延迟处理节点信息
struct delayhandle_node
{
	int time;	//处理时间
	char class;	//任务类别：0下载，1获取未读信息
	
	char url[30]; 	//要下载文件名
	char code;		//要查询信息代码
	
	char md5[32];
	int size;
	
	struct delayhandle_node *next;	
};

struct proto_data
{
	int recvnum;		//接收报文数量
	int sendnum;		//发送报文数量
	int recvrenum;		//接收重复报文数量
	int sendrenum;		//发送重复报文数量
	int relateallnum;	//关联人总数
	int relatelogin;	//登录关联人数量
	int filenum;		//打开文件数量
	
	int	sequence;		//系统唯一数产生器

	pthread_mutex_t		data_lock;	//访问除文件以外的其他锁
	
	pthread_t 	timer_thread;			//定时器线程
	pthread_t 	nethandle_thread;		//网络数据接收处理线程
	int			timer_run;				//定时器是否运行
	int 		nethandle_run;			//网络接收线程是否运行
	int 		sockfd;					//远程通信网络套接字描述符	
	
	moduleCallback		callback;		//访问其他模块功能的回调函数指针
	struct proto_config cfg;			//模块配置
	
	struct plat_inf		platinf;		//平台数据信息
	struct relater_node		*userlist;	//关联人列表
	
	struct file_node		*filelist;	//打开文件列表
	struct posthandle_node	*postlist;	//后处理列表
	struct delayhandle_node *delaylist;	//延迟处理列表
	
	int (*proto_proc[12])(struct pkt_inf *msg);
};

struct loginf
{
	char type; //0错误，1 local operation， 2 remote control, 3 alarm;
	char username[20];
	char ret;  //0成功，1失败
	char data[58]; //操作或者错误信息
};
	
//外部接口函数定义	
int proto_init(struct KeyValueArray  *cfg, moduleCallback callback, struct ModuleInfo* ret);
int proto_close(void);
int proto_query(int type, void *input, void *output); 
int proto_config(int type, void*cfg); 
int proto_control(int sendid, int type, void * input, void * output);

//内部接口函数定义
int proto_log(struct loginf *loginf, char show);
int proto_errlog(char *errinf, char show);
int proto_execctl(int code, void *input , void *output, char tag);
int proto_update(int type, char *url);
int proto_deal(struct pkt_inf *msg);

//线程处理函数定义
void *proto_timer(void *arg);
void *proto_nethandle(void *arg);

//中间处理函数定义
int proto_recvproc(struct pkt_inf *msg);
int proto_sendproc(struct pkt_inf *msg, int type);

//启动发送报文
int proto_login_start(int source);
int proto_keeplive_start(void);
int proto_logout_start(void);
int proto_test_start(void);
int proto_register_start(void);
int proto_regoff_start(void);
int proto_update_start(int source);
int proto_query_start(void);
int proto_alarm_start(struct alarm_inf *msg, int id);
int proto_alarm_startall(struct alarm_inf *msg);
int proto_file_start(void);
int proto_sync_start(int kind, int source);

int proto_init_relater(void);
void proto_free(void);
int proto_netinit(void);
int parse_pkthead(struct pkt_inf *msg);
int encap_pkthead(struct pkt_inf *msg, int type);

int proto_deal_test(struct pkt_inf *msg);
int proto_deal_login(struct pkt_inf *msg);
int proto_deal_account(struct pkt_inf *msg);
int proto_deal_control(struct pkt_inf *msg);
int proto_deal_deliver(struct pkt_inf *msg);
int proto_deal_find(struct pkt_inf *msg);
int proto_deal_file(struct pkt_inf *msg);
int proto_deal_encode(struct pkt_inf *msg);
int proto_deal_relate(struct pkt_inf *msg);
int proto_notsupport(struct pkt_inf *msg);
int proto_async_proc(int code, void *output);
#endif
