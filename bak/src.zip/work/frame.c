﻿//智能监控框架管理模块
#include "work.h"

struct work_data *pworkdata;

//处理模块的回调
int work_callback(int sendid, int recvid, int type, void *input, void *output)
{
	return 0;
}

//功能模块关闭处理
int work_close()
{
	free(pworkdata);
	return 0;
}

//功能模块的控制处理
int work_control(int funcid, int type, void *input, void *output)
{
	return 0;
}

//功能模块初始化处理
int work_init(int num, smartCallback callback)
{
	pworkdata = (struct work_data *)calloc(1,sizeof(struct work_data));
	//检查必要的环境
	//初始化数据结构workdata
	//依次调用各个模块的初始化

	return 0;
}

