﻿#include <stdio.h>
#include "work.h"

extern struct work_data *pworkdata;

int smart_callback(int funcid, int type, void *input, void *output)
{
	return 0;
}

void ac_exit_system(int num)
{
	pworkdata->ifexit = 1;
}

void pid_init()
{
	signal(SIGINT, ac_exit_system);/*register signal handler*/
	signal(SIGTERM, ac_exit_system);/*register signal handler*/
	signal(SIGKILL, ac_exit_system);/*register signal handler*/
}

int main() {
	pid_init();

	work_init(5,smart_callback);
	while (!pworkdata->ifexit) 
	{
		
		usleep(1);
	}
	
	work_close();
	return 0;
}
